/**
 */
package extTRADES;

import dsm.TRADES.Threat;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ext Threat</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see extTRADES.ExtTRADESPackage#getextThreat()
 * @model
 * @generated
 */
public interface extThreat extends Threat, extElement {

} // extThreat
