/**
 */
package extTRADES;

import dsm.TRADES.Control;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ext Control</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see extTRADES.ExtTRADESPackage#getExtControl()
 * @model
 * @generated
 */
public interface ExtControl extends Control, extElement {
} // ExtControl
